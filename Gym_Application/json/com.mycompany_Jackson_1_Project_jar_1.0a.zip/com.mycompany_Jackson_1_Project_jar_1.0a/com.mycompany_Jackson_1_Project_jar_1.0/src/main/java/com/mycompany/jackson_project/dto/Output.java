/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.jackson_project.dto;
import java.util.List;
/**
 *
 * @author mdipa
 */
public class Output{
    public List<Element> elements;
}
