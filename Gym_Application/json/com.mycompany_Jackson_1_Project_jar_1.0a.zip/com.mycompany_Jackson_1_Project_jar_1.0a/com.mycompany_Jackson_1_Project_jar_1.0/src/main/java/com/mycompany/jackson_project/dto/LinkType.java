/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.jackson_project.dto;

/**
 *
 * @author mdipa
 */
public class LinkType{
    public String value;
    public String localValue;
    public String localTranslation;
}
