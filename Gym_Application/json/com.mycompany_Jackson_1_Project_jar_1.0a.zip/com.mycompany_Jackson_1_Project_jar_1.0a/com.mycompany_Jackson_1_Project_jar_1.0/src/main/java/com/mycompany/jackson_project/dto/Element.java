/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.jackson_project.dto;

/**
 *
 * @author mdipa
 */
import java.util.List;

public class Element{
    public Object id;
    public String type;
    public List<Object> connectionId;
    public Dictionary dictionary;
    public String description;
    public String name;
    public Object hierarchyId;
    public String begin;
    public String end;
    public int statusId;
    public int connectionNodeSeq;
    public Object borderCod;
    public String tcCod;
    public String legacyCod;
    public Object legacyCodLv;
    public String legacyNodeType;
    public String networkType;
    public String voltageType;
    public int regionId;
    public int organizationId;
    public int territoryId;
    public int targetTypeId;
    public Object borderProfileId;
    public int lineId;
    public int electricalLineId;
    public String borderFlg;
    public List<Hierarchy> hierarchy;
    public double graphicalLength;
    public double conductorLength;
    public double conductorSection;
    public Object neutralSection;
    public double phases;
    public Object conductorPerPhase;
    public Object neutralFlg;
    public Object normFlg;
    public Object publicLightingFlg;
    public double vNominal;
    public double vClearance;
    public double iMaxShortc;
    public double iMaxTherm;
    public Object iRange;
    public Object rPhase;
    public Object xPhase;
    public Object kPhase;
    public Object rNeutral;
    public Object xNeutral;
    public Object kNeutral;
    public double rDirect;
    public double xDirect;
    public double bDirect;
    public double rHomopolar;
    public double xHomopolar;
    public double bHomopolar;
    public int ownershipId;
    public Object companyId;
    public Object responsibleId;
    public int layingTypeId;
    public int lineTypeId;
    public int cableTypeId;
    public int lineSegmentClassId;
    public int conductorMaterialId;
    public int neutralMaterialId;
    public Object sheathMaterialId;
    public int protectionTypeId;
    public int insulationTypeId;
    public int conductorSupportId;
    public Object conductorTypeId;
    public String closeFlg;
    public String mainFlg;
    public Object iNominal;
    public Object label;
    public int switchTypeId;
    public int controlTypeId;
    public int reclosingTypeId;
    public int faultDetectionId;
    public String busbarGroup;
    public int busbarSeq;
    public int busbarTypeId;
    public int neutralTypeId;
    public int compartmentTypeId;
    public int equipmentTypeId;
    public Object equipmentClassId;
    public Object windingDesc;
    public double paNominal;
    public double pPercShortc;
    public double vPercShortc;
    public double coupleGTransvDirect;
    public double coupleBTransvDirect;
    public double coupleGTransvHomopolar;
    public double coupleBTransvHomopolar;
    public double rLongitDirect;
    public double xLongitDirect;
    public double gTransvDirect;
    public double bTransvDirect;
    public double rLongitHomopolar;
    public double xLongitHomopolar;
    public double gTransvHomopolar;
    public double bTransvHomopolar;
    public Object switchStepNum;
    public Object neutralStep;
    public Object actualStep;
    public Object vPercStep;
    public String transformerWindingSeq;
    public int linkTypeId;
    public String idx;
    public double qNominal;
    public double gDirect;
    public Object zHomopolar;
    public double gHomopolar;
    public int compensatorTypeId;
    public double parallelTrasfNum;
    public double ironLoss;
    public double iNoload;
    public int transformerClassId;
    public Object transformerTypeId;
}
