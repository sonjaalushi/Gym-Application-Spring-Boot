/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.jackson_project.dto;

/**
 *
 * @author mdipa
 */

public class Hierarchy{
    public Dictionary dictionary;
    public Object id;
    public String description;
    public String name;
    public Object hierarchyId;
    public String type;
    public String begin;
    public String end;
    public int statusId;
    public String tcCod;
    public String legacyCod;
    public int baySeq;
    public String schemaCod;
    public String legacyNodeType;
    public String networkType;
    public String voltageType;
    public int regionId;
    public int ownershipId;
    public Object companyId;
    public int organizationId;
    public int territoryId;
    public double vNominal;
    public double vClearance;
    public double vOperating;
    public Object systemType;
    public Object locationType;
    public String externalCod;
    public String address;
    public int responsibleId;
    public int maintenanceId;
    public int stationTypeId;
    public int buildingTypeId;
    public Object plannedLineId;
}

