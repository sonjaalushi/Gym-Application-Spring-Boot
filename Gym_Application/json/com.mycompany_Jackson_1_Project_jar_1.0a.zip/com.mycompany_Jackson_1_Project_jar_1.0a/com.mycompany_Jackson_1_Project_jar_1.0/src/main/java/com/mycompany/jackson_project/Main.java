/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.jackson_project;
import java.io.File ;
import java.util.*;
//import Models.Root ;
import com.fasterxml.jackson.databind.ObjectMapper ; 
import com.mycompany.jackson_project.dto.Root;
import com.mycompany.jackson_project.dto.Element;
import java.io.IOException;
        
/**
 *
 * @author mdipa
 */
public class Main {
        @SuppressWarnings("CallToPrintStackTrace")
        
        
  public static Elem_Trasf findEleById(
  String idX, List<Elem_Trasf> eleTr) {

    for (Elem_Trasf ele : eleTr) {
        if (ele.id.equals(idX)) {
            return ele;
        }
    }
    return null;
}
        
        public static void main(String[] args) {

// Variabili            
        int i = 0;
        String conn =""; 
        int eleConn =-1;
        String eleConnStr = "";
        Elem_Trasf connesso ; 
        List<Elem_Trasf> eleTr_lst = new ArrayList<Elem_Trasf>();
/*
        objectMapper.configure(
    DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
*/        
                    System.out.println("Inizio");        
            try {

                ObjectMapper om = new ObjectMapper();
                
                // Element Example
                
                Root root = om.readValue (new File("C:\\Users\\User\\Downloads\\com.mycompany_Jackson_1_Project_jar_1.0a\\com.mycompany_Jackson_1_Project_jar_1.0\\src\\main\\java\\com\\mycompany\\jackson_project\\estrazione_MT.json"), Root.class) ;
//              Esempio accesso ad un elemento di elements     
//                System.out.println(root.output.elements.get(1).type + ' ' + root.output.elements.get(1).id );

// Ciclo For 
/*
            for(Element elem : root.output.elements) {
                System.out.println(elem.type + ' ' + elem.id );
            }
*/
///////////////////////////////////////////////////
// Print Data From the list of Elements
///////////////////////////////////////////////////
            for (Iterator<Element> it = root.output.elements.iterator(); it.hasNext();) {
                Element elem = it.next();
                try {
                conn = elem.connectionId.get(0).toString() ;
                }
                catch (Exception e){ System.out.println(e) ;
                conn = "ND"; 
                }
                System.out.println("TYPE: " + elem.type + " ID: " + elem.id + " CONN_ID: "+ conn );
                eleTr_lst.add(new Elem_Trasf(elem.id.toString() , elem.name, elem.type, conn) ) ;
            }

///////////////////////////////////////////////////
// Print Data From the list of Elem_Trasf
///////////////////////////////////////////////////     
            System.out.println("--------------------- Secondo Ciclo ----------------------------");  
            i = 0 ;            
            for (Iterator<Elem_Trasf> nt = eleTr_lst.iterator(); nt.hasNext(); i++) {
                Elem_Trasf et = nt.next() ;
                
                if (et.connectionId  == null ) {
                System.out.println("ID: " + et.id + " NAME: " + et.name + " TYPE: " + et.type + " CONN_ID: ND");  

                }
                else {
                connesso = findEleById(et.connectionId, eleTr_lst) ;
                           if ( connesso == null ) { 
                             System.out.println("ID: " + et.id + " NAME: " + et.name + " TYPE: " + et.type + " CONN_ID: "+ et.connectionId + " Non Trovata Connessione") ;
                       }
                //           else { System.out.println("Connesso : " + connesso.name.toString()+ " " + connesso.name.toString()) ; }
                    else {
                    System.out.println("ID: " + et.id + " NAME: " + et.name + " TYPE: " + et.type + " CONN_ID: "+ et.connectionId  + " CONN_NAME: "+ connesso.name + " CONN_Type: "+ connesso.type + " CONN_ID: "+ connesso.id) ;  
                    }
                }
/*                
                if (eleConn > 0 ) {
                 System.out.println("ID: " + et.id + " NAME: " + et.name + " TYPE: " + et.type + " CONN_ID: "+ et.connectionId + " CONN_ID: "+eleTr_lst.get(eleConn).id + " CONN_NAME: "+eleTr_lst.get(eleConn).name);    
                  }
                else {
                 System.out.println("ID: " + et.id + " NAME: " + et.name + " TYPE: " + et.type + " CONN_ID: "+ et.connectionId + " CONN_ID: "+eleTr_lst.get(eleConn).id + " CONN_NAME: ND");    
                  }
*/  
          }
            /*
            // Array Example : Non funziona con questo file va cambiato esempio e struttura
            Root[] root2  = om.readValue(new File("C:\\Users\\mdipa\\Documents\\Netbeans\\Jackson_Project\\src\\main\\java\\com\\mycompany\\jackson_project\\test-json.json"), Root[].class);
            int arrayLength=root2.length ;
            for (i = 0; i < arrayLength; i++) {
            System.out.print(root2[i] + " ");
            }
             */ //root2.forEach(lstitem->System.out.println(lstitem));                 
                
            } catch (IOException e ) {
               e.printStackTrace();
            }
        }
}