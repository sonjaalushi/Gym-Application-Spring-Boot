/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.jackson_project.dto;

/**
 *
 * @author mdipa
 */

public class Dictionary{
    public Status status;
    public BorderProfile borderProfile;
    public Ownership ownership;
    public LayingType layingType;
    public LineType lineType;
    public CableType cableType;
    public LineSegmentClass lineSegmentClass;
    public ConductorMaterial conductorMaterial;
    public NeutralMaterial neutralMaterial;
    public SheathMaterial sheathMaterial;
    public ProtectionType protectionType;
    public InsulationType insulationType;
    public SwitchType switchType;
    public ControlType controlType;
    public ReclosingType reclosingType;
    public FaultDetection faultDetection;
    public BusbarType busbarType;
    public NeutralType neutralType;
    public CompartmentType compartmentType;
    public EquipmentType equipmentType;
    public EquipmentClass equipmentClass;
    public LinkType linkType;
    public CompensatorType compensatorType;
    public TransformerClass transformerClass;
    public SystemType systemType;
    public LocationType locationType;
    public StationType stationType;
    public BuildingType buildingType;
}
