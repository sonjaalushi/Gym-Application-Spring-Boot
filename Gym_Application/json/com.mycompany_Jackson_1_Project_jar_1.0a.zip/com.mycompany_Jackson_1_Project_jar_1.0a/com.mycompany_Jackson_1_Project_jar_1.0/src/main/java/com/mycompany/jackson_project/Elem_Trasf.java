/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.jackson_project;

/**
 *
 * @author mdipa
 */
public class Elem_Trasf {
    
    public String id;
    public String name ;
    public String type ;
    public String connectionId ;
    
    public Elem_Trasf (String i, String n, String t, String c){ 
        this.id = i ;
        this.name = n ;
        this.type = t ;
        this.connectionId = c ;
     } 
}
